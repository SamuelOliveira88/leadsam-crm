/*
 * Mi Zap — configuração
 * A chave abaixo é a "publishable" (pública), a mesma do app.
 * NUNCA coloque a service_role aqui.
 */
const CONFIG = {
  SUPABASE_URL: "https://peypojjxtaigrqembbqo.supabase.co",
  SUPABASE_KEY: "sb_publishable_xSyyR0E9h7uY2RMc4m7Zgw_TvhYX390"
};
