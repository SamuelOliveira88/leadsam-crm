/*
 * Mi Zap — service worker
 *
 * Privacidade: a sessão fica em chrome.storage.session (some ao fechar o navegador
 * e o content script não tem acesso). Só fala com o Supabase, só chama funções ext_*.
 */
importScripts("config.js");

const PERMITIDAS = new Set([
  "ext_ficha", "ext_etapa", "ext_nota", "ext_assumir", "ext_lembrete",
  "ext_atribuir", "ext_nao_cliente", "ext_respostas_listar", "ext_resposta_salvar", "ext_resposta_apagar", "ext_empreendimentos",
  "ext_planilha_listar", "ext_planilha_salvar", "ext_planilha_importar",
  "ext_disparo_previa", "ext_disparo_criar", "ext_disparo_status", "ext_disparo_listar",
  "ext_modelo_listar", "ext_modelo_salvar", "ext_modelo_apagar", "ext_disparo_por_empreendimento",
  "ext_plano_meu", "ext_plano_definir", "ext_planos_listar",
  "ext_etapas_listar", "ext_etapa_salvar", "ext_etapas_ordenar", "ext_etapa_apagar",
  "ext_quadros_listar", "ext_quadro_salvar", "ext_quadro_apagar", "ext_coluna_salvar", "ext_coluna_apagar", "ext_cartao_mover",
  "ext_sara_config_ler", "ext_sara_config_salvar",
  "ext_qr_pedir", "ext_qr_status", "ext_qr_cancelar",
  "ext_convite_criar", "ext_equipe_listar", "ext_convite_cancelar", "ext_corretor_ativo", "ext_aceitar_convite", "ext_cadastro_livre"
]);

// Foto do disparo: sobe pro bucket público disparo-midia/<corretor>/... e devolve a URL https.
async function subirFoto(corretor, dataUrl) {
  const m = /^data:(image\/(jpeg|png|webp));base64,(.+)$/.exec(dataUrl || "");
  if (!m) throw new Error("Só imagem JPG, PNG ou WEBP.");
  const bytes = Uint8Array.from(atob(m[3]), (c) => c.charCodeAt(0));
  if (bytes.length > 5 * 1024 * 1024) throw new Error("Foto acima de 5 MB.");
  if (!/^[a-z0-9_.-]+$/i.test(corretor || "")) throw new Error("corretor inválido");
  const nome = corretor + "/" + Date.now() + "-" + Math.random().toString(36).slice(2, 8) + "." + (m[2] === "jpeg" ? "jpg" : m[2]);
  const tk = await tokenValido();
  const r = await fetch(CONFIG.SUPABASE_URL + "/storage/v1/object/disparo-midia/" + nome, {
    method: "POST",
    headers: { "apikey": CONFIG.SUPABASE_KEY, "Authorization": "Bearer " + tk, "Content-Type": m[1], "x-upsert": "false" },
    body: bytes
  });
  if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error("Não subiu a foto: " + (j.message || j.error || r.status)); }
  return CONFIG.SUPABASE_URL + "/storage/v1/object/public/disparo-midia/" + nome;
}

async function lerSessao() { return (await chrome.storage.session.get("sessao")).sessao || null; }
async function gravarSessao(s) { await chrome.storage.session.set({ sessao: s }); }

async function auth(caminho, corpo) {
  const r = await fetch(CONFIG.SUPABASE_URL + "/auth/v1/" + caminho, {
    method: "POST",
    headers: { "apikey": CONFIG.SUPABASE_KEY, "Content-Type": "application/json" },
    body: JSON.stringify(corpo)
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error_description || j.msg || "Falha no login");
  return j;
}

function montarSessao(j) {
  return { access_token: j.access_token, refresh_token: j.refresh_token,
           expira: Date.now() + (j.expires_in || 3600) * 1000, email: (j.user && j.user.email) || "" };
}

async function tokenValido() {
  let s = await lerSessao();
  if (!s) throw new Error("sem_login");
  if (Date.now() > s.expira - 60000) {
    try { s = montarSessao(await auth("token?grant_type=refresh_token", { refresh_token: s.refresh_token })); await gravarSessao(s); }
    catch (e) { await chrome.storage.session.remove("sessao"); throw new Error("sem_login"); }
  }
  return s.access_token;
}

async function rpc(fn, args) {
  if (!PERMITIDAS.has(fn)) throw new Error("função não permitida");
  const tk = await tokenValido();
  const r = await fetch(CONFIG.SUPABASE_URL + "/rest/v1/rpc/" + fn, {
    method: "POST",
    headers: { "apikey": CONFIG.SUPABASE_KEY, "Authorization": "Bearer " + tk, "Content-Type": "application/json" },
    body: JSON.stringify(args || {})
  });
  const j = await r.json().catch(() => null);
  if (!r.ok) {
    const m = (j && (j.message || j.hint)) || ("erro " + r.status);
    const AMIGAVEL = {
      acesso_negado: "Seu login não está liberado na extensão (ext_corretores).",
      lead_sem_dono: "Esse lead ainda não tem dono. Peça pro admin atribuir a você.",
      lead_de_outro_corretor: "Esse lead é de outro corretor.",
      contato_da_sara: "Esse contato é atendido pela Mi.IA do admin.",
      sara_so_admin: "Só o admin mexe na Mi.IA de quem ainda não é lead.",
      so_admin: "Só o admin pode fazer isso.",
      plano_ferramentas: "🔒 Disponível no plano com Ferramentas (funil, planilha, disparo, equipe). Veja a aba Meu plano.",
      plano_ia: "🔒 Disponível no módulo Mi.IA. Veja a aba Meu plano.",
      so_super: "Só o dono da plataforma cria convite para outra empresa.",
      marcado_nao_cliente: "Esse contato está marcado como Não é cliente. Use o botão É cliente, sim.",
      nao_estava_marcado: "Esse contato não estava marcado como Não é cliente.",
      aceite_obrigatorio: "Marque que você aceita o risco do envio pela Evolution.",
      sem_instancia_whatsapp: "Seu login não tem número de WhatsApp (evo_instancia) cadastrado.",
      midia_precisa_https: "A foto precisa ser um link https.",
      maximo_2000_por_vez: "Importe no máximo 2000 linhas por vez.",
      campanha_nao_encontrada: "Campanha não encontrada ou já encerrada.",
      lead_nao_encontrado: "Contato não encontrado.",
      convite_invalido: "Código de convite inválido, vencido ou já usado. Peça um novo ao admin.",
      ja_cadastrado: "Esse login já está cadastrado na extensão.",
      nome_invalido: "Escreva seu nome.",
      cadastro_cheio: "Os cadastros grátis de hoje acabaram. Tente amanhã ou peça um convite."
    };
    const chave = Object.keys(AMIGAVEL).find((k) => m.includes(k));
    throw new Error(chave ? AMIGAVEL[chave] : m);
  }
  return j;
}

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  (async () => {
    try {
      if (msg.tipo === "login") {
        const s = montarSessao(await auth("token?grant_type=password", { email: msg.email, password: msg.senha }));
        await gravarSessao(s);
        return { ok: true, email: s.email };
      }
      if (msg.tipo === "criar_conta") {
        // cadastro com a chave pública: o login novo não acessa nada até usar um convite válido
        const j = await auth("signup", { email: msg.email, password: msg.senha, data: { nome: msg.nome } });
        if (j.access_token) { const s = montarSessao(j); await gravarSessao(s); return { ok: true, logado: true, email: s.email }; }
        return { ok: true, logado: false };  // o Supabase pediu confirmação por e-mail
      }
      if (msg.tipo === "logout") {
        const s = await lerSessao();
        if (s) await fetch(CONFIG.SUPABASE_URL + "/auth/v1/logout", { method: "POST",
          headers: { "apikey": CONFIG.SUPABASE_KEY, "Authorization": "Bearer " + s.access_token } }).catch(() => {});
        await chrome.storage.session.remove("sessao");
        return { ok: true };
      }
      if (msg.tipo === "status") { const s = await lerSessao(); return { ok: true, logado: !!s, email: s ? s.email : "" }; }
      if (msg.tipo === "foto") return { ok: true, url: await subirFoto(msg.corretor, msg.dataUrl) };
      if (msg.tipo === "rpc") return { ok: true, dados: await rpc(msg.fn, msg.args) };
      return { ok: false, erro: "pedido desconhecido" };
    } catch (e) { return { ok: false, erro: e.message }; }
  })().then(responder);
  return true;
});
