/*
 * Mi Zap — barra lateral (content script)
 *
 * O que este arquivo FAZ:   descobre o número do contato aberto, mostra a ficha,
 *                           e (só quando você clica) grava etapa, nota, lembrete, pausa da Mi.IA,
 *                           ou coloca um texto pronto na caixa de digitação.
 * O que ele NUNCA faz:      ler o texto das mensagens, copiar conversas, ler cookies,
 *                           baixar áudio/mídia, enviar mensagem sozinho, carregar script de fora.
 */
(() => {
  if (window.__alexandriaWA) return; window.__alexandriaWA = true;

  const LARG = 340;
  const TRILHO = 64; // menu de ícones colado na esquerda
  let candidato = null, estado = "", aberto = true, telAtual = null, chatAtual = "", ficha = null, ocupado = false;

  // ---------- comunicação com o service worker ----------
  const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(r || { ok: false, erro: "sem resposta" })));
  const rpc = async (fn, args) => { const r = await bg({ tipo: "rpc", fn, args }); if (!r.ok) throw new Error(r.erro); return r.dados; };

  // ---------- descobrir o contato aberto (só número; nada de mensagens) ----------
  function tituloChat() {
    const h = document.querySelector("#main header");
    if (!h) return "";
    const s = h.querySelector("span[title], span[dir='auto']");
    return (s && (s.getAttribute("title") || s.textContent) || "").trim();
  }
  function telefoneDoChat() {
    const main = document.querySelector("#main");
    if (!main) return null;
    // 1) o id interno das linhas da conversa traz o número (ex.: false_5511999999999@c.us_...). Lemos só o atributo.
    if (main.querySelector("[data-id*='@g.us']")) return null; // grupo: não pegar número de participante
    const el = main.querySelector("[data-id*='@c.us']");
    if (el) { const m = el.getAttribute("data-id").match(/_(\d{10,15})@c\.us/); if (m) return m[1]; }
    // 2) contato não salvo: o título do cabeçalho é o próprio número
    const t = tituloChat().replace(/[^\d+]/g, "");
    if (/^\+?\d{10,15}$/.test(t)) return t.replace("+", "");
    return null; // grupo, contato com ID oculto (@lid) ou chat sem mensagens: pede o número
  }

  // ---------- montar a barra (Shadow DOM: o WhatsApp não enxerga, e nosso CSS não vaza) ----------
  const host = document.createElement("div");
  host.id = "alexandria-wa";
  host.style.cssText = `position:fixed;top:0;right:0;height:100vh;width:${LARG}px;z-index:2147483000;`;
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
  <style>
    :host{all:initial}
    *{box-sizing:border-box;font-family:Segoe UI,Helvetica,Arial,sans-serif}
    .p{height:100%;background:#fff;border-left:1px solid #d1d7db;display:flex;flex-direction:column;color:#111b21;font-size:13px}
    .top{background:#00a884;color:#fff;padding:10px 12px;display:flex;align-items:center;gap:8px}
    .top b{flex:1;font-size:14px}
    .top button{background:transparent;border:0;color:#fff;font-size:16px;cursor:pointer}
    .c{overflow:auto;padding:10px 12px;flex:1}
    .sec{border-bottom:1px solid #eef0f1;padding:8px 0}
    .sec h4{margin:0 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#667781}
    .nome{font-size:16px;font-weight:600}
    .row{display:flex;justify-content:space-between;gap:8px;padding:2px 0}
    .row span:first-child{color:#667781}
    .chip{display:inline-block;padding:2px 8px;border-radius:10px;background:#e7fce3;color:#027b5b;font-size:11px;margin-right:4px}
    .q{background:#ffe9e5;color:#b42318}.m{background:#fff4e5;color:#a15c07}
    select,textarea,input{width:100%;border:1px solid #d1d7db;border-radius:6px;padding:6px;font-size:13px}
    textarea{resize:vertical;min-height:50px}
    button.b{border:0;border-radius:6px;padding:7px 10px;cursor:pointer;font-size:13px;background:#00a884;color:#fff;margin-top:6px}
    button.s{background:#f0f2f5;color:#111b21}
    button.w{background:#b42318}
    .lista div{padding:5px 0;border-bottom:1px dashed #eef0f1}
    .lista small{color:#667781;display:block}
    .rr{display:flex;flex-wrap:wrap;gap:6px}
    .rr button{background:#f0f2f5;border:1px solid #d1d7db;border-radius:14px;padding:4px 10px;cursor:pointer;font-size:12px}
    .msg{padding:8px;border-radius:6px;background:#f0f2f5;margin:6px 0;color:#3b4a54}
    .erro{background:#ffe9e5;color:#b42318}
    a{color:#027b5b}
    .resumo{white-space:pre-wrap;background:#f7f8fa;padding:6px;border-radius:6px}
    .tab{position:fixed;top:120px;right:${LARG}px;background:#00a884;color:#fff;border:0;border-radius:6px 0 0 6px;padding:8px 6px;cursor:pointer;writing-mode:vertical-rl;font-size:12px}
  </style>
  <button class="tab" id="tab">Alexandria</button>
  <div class="p" id="p">
    <div class="top"><b>Alexandria</b><button id="rec" title="Atualizar">⟳</button><button id="fec" title="Recolher">✕</button></div>
    <div class="c" id="c"></div>
  </div>`;
  document.documentElement.appendChild(host);
  const $ = (id) => root.getElementById(id);
  const C = $("c");

  function aplicarLargura() {
    const app = document.getElementById("app");
    host.style.width = aberto ? LARG + "px" : "0px";
    $("p").style.display = aberto ? "flex" : "none";
    $("tab").style.right = (aberto ? LARG : 0) + "px";
    if (app) {
      app.style.marginLeft = TRILHO + "px";
      app.style.width = `calc(100% - ${TRILHO + (aberto ? LARG : 0)}px)`;
    }
    if (typeof marcarFicha === "function") marcarFicha();
  }
  function alternarFicha(forcar) { aberto = forcar ?? !aberto; aplicarLargura(); if (aberto) carregar(true); }
  $("tab").onclick = () => alternarFicha();
  $("fec").onclick = () => { aberto = false; aplicarLargura(); };
  $("rec").onclick = () => carregar(true);

  // ---------- helpers de tela (sempre textContent: nada de HTML vindo do banco) ----------
  const el = (tag, props = {}, ...filhos) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) { if (k === "on") for (const [ev, fn] of Object.entries(v)) e.addEventListener(ev, fn); else if (k === "class") e.className = v; else e[k] = v; }
    for (const f of filhos) if (f != null) e.append(f.nodeType ? f : document.createTextNode(String(f)));
    return e;
  };
  const sec = (titulo, ...f) => el("div", { class: "sec" }, el("h4", {}, titulo), ...f);
  const linha = (k, v) => v ? el("div", { class: "row" }, el("span", {}, k), el("span", {}, v)) : null;
  const aviso = (t, erro) => el("div", { class: "msg" + (erro ? " erro" : "") }, t);
  const dataBR = (iso) => { try { return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } };
  const dinheiro = (v) => (v && !isNaN(Number(v))) ? "R$ " + Number(v).toLocaleString("pt-BR") : v;
  const fgtsTxt = (v) => v === true || v === "true" || v === "sim" ? "tem" : (v === false || v === "false" || v === "nao" || v === "não") ? "não tem" : dinheiro(v);

  function telaLogin() {
    estado = "login";
    C.replaceChildren(aviso("Entre pelo ícone da extensão (barra do Chrome) com o mesmo login do app do Jarbas."));
  }
  function telaSemNumero() {
    const inp = el("input", { placeholder: "Número com DDD, ex.: 11 99999-9999" });
    C.replaceChildren(...[
      aviso(chatAtual ? "Não consegui ver o número desta conversa (grupo, contato com número oculto ou conversa vazia)." : "Abra uma conversa."),
      chatAtual ? el("div", {}, inp, el("button", { class: "b", textContent: "Buscar ficha", on: { click: () => { const d = inp.value.replace(/\D/g, ""); if (d.length >= 10) { telAtual = d; carregar(true); } } } })) : null
    ].filter(Boolean));
  }

  // ---------- caixa de digitação: só coloca o texto, quem envia é você ----------
  function colocarNaCaixa(texto) {
    const box = document.querySelector("#main footer div[contenteditable='true']");
    if (!box) return alert("Abra uma conversa primeiro.");
    const nome = ficha && ficha.nome ? String(ficha.nome).split(" ")[0] : "";
    texto = texto.replace(/\{nome\}/g, nome).replace(/\{empreendimento\}/g, (ficha && ficha.empreendimento) || "");
    box.focus();
    document.execCommand("insertText", false, texto);
  }

  async function acao(fn, args, okMsg) {
    if (ocupado) return; ocupado = true;
    try { await rpc(fn, args); await carregar(true, okMsg); }
    catch (e) { C.prepend(aviso(e.message, true)); }
    finally { ocupado = false; }
  }

  function quando(tipo) {
    const d = new Date();
    if (tipo === "2h") d.setHours(d.getHours() + 2);
    if (tipo === "amanha9") { d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); }
    if (tipo === "amanha14") { d.setDate(d.getDate() + 1); d.setHours(14, 0, 0, 0); }
    return d.toISOString();
  }

  function telaFicha(f, okMsg) {
    const tel = telAtual;
    const blocos = [];
    if (okMsg) blocos.push(aviso(okMsg));

    // Ficha
    const temp = f.temperatura ? el("span", { class: "chip " + (f.temperatura === "quente" ? "q" : f.temperatura === "morno" ? "m" : ""), textContent: f.temperatura }) : null;
    blocos.push(el("div", { class: "sec" },
      el("div", { class: "nome" }, f.nome || chatAtual || ("+" + tel)), temp,
      f.encontrado ? null : aviso("Esse contato ainda não está na base da Mi.IA nem no Alexandria."),
      linha("Renda", dinheiro(f.renda)), linha("FGTS", fgtsTxt(f.fgts)),
      linha("Empreendimento", f.empreendimento), linha("Origem", f.tag ? "#" + f.tag : f.origem),
      linha("Interesse", f.interesse),
      f.motivo_quente ? linha("Por que quente", f.motivo_quente) : null,
      f.resumo ? el("div", { class: "resumo" }, f.resumo) : null
    ));

    // Dono do lead (admin escolhe)
    if (f.lead_id && f.sou_admin && (f.corretores || []).length) {
      const sd = el("select", {}, el("option", { value: "", textContent: "(sem dono)" }), ...f.corretores.map((k) => el("option", { value: k.id, textContent: k.nome, selected: k.id === f.dono })));
      sd.addEventListener("change", () => acao("ext_atribuir", { p_telefone: tel, p_corretor_id: sd.value }, "Dono atualizado."));
      blocos.push(sec("Dono do lead", sd));
    }

    // Mi.IA
    const naoCliente = f.pausado_motivo === "nao_cliente";
    let saraTxt = naoCliente ? "Marcado como Não é cliente. A Mi.IA não fala com esse contato." : !f.sara_existe ? "A Mi.IA ainda não conversou com esse contato." : f.opt_out ? "O cliente pediu para PARAR. A Mi.IA não volta a falar com ele." : f.sara_pausada ? "Você está com o cliente (Mi.IA pausada)." : "A Mi.IA está atendendo.";
    const btnSara = f.opt_out ? null : (f.sara_pausada || !f.sara_existe)
      ? (f.sara_existe ? el("button", { class: "b", textContent: "Devolver para a Mi.IA", on: { click: () => acao("ext_assumir", { p_telefone: tel, p_eu_assumo: false }, "A Mi.IA voltou a atender.") } })
                       : el("button", { class: "b s", textContent: "Eu assumo (Mi.IA não entra)", on: { click: () => acao("ext_assumir", { p_telefone: tel, p_eu_assumo: true }, "Pronto, a Mi.IA fica fora dessa conversa.") } }))
      : el("button", { class: "b w", textContent: "Eu assumo", on: { click: () => acao("ext_assumir", { p_telefone: tel, p_eu_assumo: true }, "Mi.IA pausada. O cliente é seu.") } });
    const btnNC = f.opt_out ? null : naoCliente
      ? el("button", { class: "b", textContent: "É cliente, sim", on: { click: () => acao("ext_nao_cliente", { p_telefone: tel, p_nao_cliente: false }, "Pronto, a Mi.IA volta a atender.") } })
      : el("button", { class: "b", textContent: "Não é cliente", title: "Colega corretor, parceiro, fornecedor ou família: a Mi.IA não fala com ele", on: { click: () => confirm("Marcar como Não é cliente? A Mi.IA para de vez nesse contato.") && acao("ext_nao_cliente", { p_telefone: tel, p_nao_cliente: true }, "Marcado. A Mi.IA não fala mais com esse contato.") } });
    blocos.push(sec("Mi.IA", el("div", {}, saraTxt), naoCliente ? null : btnSara, btnNC));

    // Etapa
    const ops = f.etapas_info && f.etapas_info.length ? f.etapas_info.map((x) => [x.chave, x.nome]) : (f.etapas || []).map((e) => [e, e]);
    if (f.lead_id && ops.length) {
      const sel = el("select", {}, ...ops.map(([k, n]) => el("option", { value: k, textContent: n, selected: k === f.etapa })));
      if (!ops.some(([k]) => k === f.etapa)) sel.prepend(el("option", { value: "", textContent: f.etapa || "(sem etapa)", selected: true }));
      sel.addEventListener("change", () => sel.value && acao("ext_etapa", { p_telefone: tel, p_etapa: sel.value }, "Etapa atualizada."));
      blocos.push(sec("Etapa", sel));
    }

    // Respostas rápidas
    const rr = (f.respostas || []);
    blocos.push(sec("Respostas rápidas",
      rr.length ? el("div", { class: "rr" }, ...rr.map((r) => el("button", { title: r.texto, textContent: r.titulo, on: { click: () => colocarNaCaixa(r.texto) } })))
                : el("small", {}, "Cadastre as suas no ícone da extensão."),
      (f.arquivos || []).length ? el("div", { class: "lista" }, ...f.arquivos.slice(0, 6).map((a) =>
        el("div", {}, el("a", { href: a.link, target: "_blank", rel: "noopener", textContent: a.nome }), " ",
           el("button", { class: "b s", textContent: "pôr link na caixa", on: { click: () => colocarNaCaixa(a.link) } })))) : null
    ));

    // Lembrete pro Jarbas
    const tit = el("input", { value: "Ligar para " + (f.nome || "o cliente") });
    const dt = el("input", { type: "datetime-local" });
    const criar = (iso) => acao("ext_lembrete", { p_telefone: tel, p_titulo: tit.value, p_quando: iso }, "Lembrete criado. O Jarbas te avisa.");
    blocos.push(sec("Lembrete (Jarbas)", tit,
      el("div", { class: "rr", style: "margin-top:6px" },
        el("button", { textContent: "Amanhã 9h", on: { click: () => criar(quando("amanha9")) } }),
        el("button", { textContent: "Amanhã 14h", on: { click: () => criar(quando("amanha14")) } }),
        el("button", { textContent: "Daqui 2h", on: { click: () => criar(quando("2h")) } })),
      el("div", { style: "margin-top:6px" }, dt, el("button", { class: "b s", textContent: "Criar nesse horário", on: { click: () => dt.value && criar(new Date(dt.value).toISOString()) } })),
      (f.tarefas || []).length ? el("div", { class: "lista" }, ...f.tarefas.map((t) => el("div", {}, t.titulo, el("small", {}, t.vencimento ? dataBR(t.vencimento) : "sem data")))) : null
    ));

    // Notas
    const nota = el("textarea", { placeholder: "Anotação sobre o cliente (só a equipe vê)" });
    blocos.push(sec("Notas", nota,
      el("button", { class: "b", textContent: "Salvar nota", on: { click: () => nota.value.trim() && acao("ext_nota", { p_telefone: tel, p_texto: nota.value }, "Nota salva.") } }),
      el("div", { class: "lista" }, ...(f.notas || []).map((n) => el("div", {}, n.texto, el("small", {}, dataBR(n.em)))))
    ));

    C.replaceChildren(...blocos.filter(Boolean));
  }

  async function carregar(forcar, okMsg) {
    if (!aberto) return;
    const st = await bg({ tipo: "status" });
    if (!st.logado) return telaLogin();
    estado = "ok";
    if (!telAtual) return telaSemNumero();
    if (!forcar && ficha && ficha.__tel === telAtual) return;
    C.replaceChildren(aviso("Carregando…"));
    try { ficha = await rpc("ext_ficha", { p_telefone: telAtual }); ficha.__tel = telAtual; try { ficha.etapas_info = await rpc("ext_etapas_listar", {}); } catch (e) { /* etapas.sql ainda não rodado: usa a lista de fábrica */ } telaFicha(ficha, okMsg); }
    catch (e) { C.replaceChildren(aviso(e.message === "sem_login" ? "Faça login no ícone da extensão." : e.message, true)); }
  }

  // ---------- acompanhar troca de conversa (só olha o cabeçalho e o id) ----------
  setInterval(() => {
    const t = tituloChat();
    if (t !== chatAtual) {
      chatAtual = t; ficha = null; telAtual = null; candidato = null;
      carregar(true); // mostra "sem número" até confirmar
    } else if (!telAtual && t) {
      // só aceita o número se aparecer igual em 2 leituras seguidas (evita pegar a conversa anterior no meio da troca)
      const n = telefoneDoChat();
      if (n && n === candidato) { telAtual = n; carregar(true); } else candidato = n;
    }
  }, 1000);

  // depois do login no popup, a barra percebe sozinha
  let tique = 0;
  setInterval(() => { if (++tique % 3 === 0 && estado === "login") carregar(true); }, 1000);

  // ---------- trilho de ícones na esquerda (Ficha, Minha Mi.IA, Funil, Planilha, Disparo, Anúncios, Respostas, Conta) ----------
  // Cada tela abre por cima do WhatsApp, num quadro da própria extensão. Nada aqui lê mensagens.
  const ICONES = {
    sara: '<circle cx="12" cy="9" r="4"/><path d="M5 20a7 7 0 0 1 14 0"/><path d="M16.5 4.5c1.8-1.2 3.6-.6 4 .9M18 3l1.2 2.4"/>',
    ficha: '<path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8a7 7 0 0 1 14 0" />',
    funil: '<rect x="3" y="4" width="5" height="16" rx="1.5"/><rect x="10" y="4" width="5" height="11" rx="1.5"/><rect x="17" y="4" width="4" height="7" rx="1.5"/>',
    planilha: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>',
    disparo: '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1Zm12-3a5 5 0 0 1 0 8m3-11a9 9 0 0 1 0 14"/>',
    anuncios: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m21 16-5-5-8 8"/>',
    respostas: '<path d="M4 5h16v10H9l-5 4V5Z"/><path d="M8 9h8M8 12h5"/>',
    empresas: '<path d="M4 21V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16M14 10h5a1 1 0 0 1 1 1v10M2 21h20M8 8h2M8 12h2M8 16h2"/>',
    conta: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M4.9 4.9 7 7m10 10 2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>'
  };
  const ITENS = [
    ["ficha", "Ficha do contato", "#00a884"],
    ["sara", "Minha Mi.IA", "#e8459b"],
    ["funil", "Funil", "#7c5cff"],
    ["planilha", "Planilha", "#1d9bf0"],
    ["disparo", "Disparo", "#ff7a00"],
    ["anuncios", "Anúncios", "#e8459b"],
    ["respostas", "Respostas rápidas", "#00b3a4"],
    ["empresas", "Minhas empresas e documentos", "#b4690e"],
    ["conta", "Conta e Sobre", "#667781"]
  ];
  const TELAS = {
    sara: ["Minha Mi.IA", "sara.html?embed=1"],
    funil: ["Funil", "planilha.html?embed=1&v=funil"],
    planilha: ["Planilha", "planilha.html?embed=1&v=tabela"],
    disparo: ["Disparo", "planilha.html?embed=1&v=disparo"],
    anuncios: ["Anúncios", "planilha.html?embed=1&v=anuncios"],
    respostas: ["Respostas rápidas", "popup.html?embed=1&t=respostas"],
    empresas: ["Minhas empresas e documentos", "empresas.html?embed=1"],
    conta: ["Conta e Sobre", "popup.html?embed=1&t=conta"]
  };
  const trilhoHost = document.createElement("div");
  trilhoHost.id = "alexandria-trilho";
  trilhoHost.style.cssText = `position:fixed;top:0;left:0;height:100vh;width:${TRILHO}px;z-index:2147483001;`;
  const tr = trilhoHost.attachShadow({ mode: "closed" });
  tr.innerHTML = `
  <style>
    :host{all:initial}
    *{box-sizing:border-box;font-family:Segoe UI,Helvetica,Arial,sans-serif}
    .t{height:100%;background:linear-gradient(180deg,#f7fffb,#eef6f3);border-right:1px solid #d1d7db;display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:8px}
    .logo{width:40px;height:40px;border-radius:14px;background:#00a884;color:#fff;font-weight:700;font-size:19px;display:flex;align-items:center;justify-content:center;margin-bottom:6px;box-shadow:0 3px 8px rgba(0,168,132,.35)}
    button{position:relative;width:44px;height:44px;border:0;border-radius:14px;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 3px rgba(17,27,33,.08);transition:transform .15s,box-shadow .15s,background .15s}
    button svg{width:22px;height:22px;fill:none;stroke:var(--c);stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
    button:hover{transform:translateY(-2px) scale(1.06);box-shadow:0 6px 14px rgba(17,27,33,.14)}
    button.on{background:var(--c)}
    button.on svg{stroke:#fff}
    button .rot{position:absolute;left:54px;top:50%;transform:translateY(-50%) translateX(-6px);background:var(--c);color:#fff;font-size:12px;font-weight:600;white-space:nowrap;padding:5px 10px;border-radius:999px;opacity:0;pointer-events:none;transition:opacity .15s,transform .15s}
    button:hover .rot{opacity:1;transform:translateY(-50%) translateX(0)}
    .esp{flex:1}
    .ov{position:fixed;top:0;left:${TRILHO}px;right:0;height:100vh;background:#fff;display:none;flex-direction:column;box-shadow:4px 0 24px rgba(0,0,0,.12)}
    .ov.on{display:flex}
    .ovtop{display:flex;align-items:center;gap:10px;padding:8px 14px;color:#fff;background:var(--c,#00a884)}
    .ovtop b{flex:1;font-size:15px}
    .ovtop button{width:auto;height:auto;padding:4px 10px;border-radius:8px;background:rgba(255,255,255,.2);box-shadow:none;color:#fff;font-size:13px}
    .ovtop button:hover{transform:none;background:rgba(255,255,255,.32)}
    iframe{flex:1;border:0;width:100%}
  </style>
  <div class="t" id="t"><div class="logo" title="Alexandria">A</div></div>
  <div class="ov" id="ov"><div class="ovtop"><b id="ovt"></b><button id="ova" title="Abrir numa aba só pra isso">Abrir em aba ↗</button><button id="ovr" title="Recarregar">⟳</button><button id="ovx" title="Fechar (Esc)">Fechar ✕</button></div><iframe id="ovf" allow="clipboard-read; clipboard-write"></iframe></div>`;
  document.documentElement.appendChild(trilhoHost);
  const T = (id) => tr.getElementById(id);
  const botoes = {};
  let telaAberta = null;
  const NS = "http://www.w3.org/2000/svg";
  for (const [id, rotulo, cor] of ITENS) {
    if (id === "conta") T("t").append(Object.assign(document.createElement("div"), { className: "esp" }));
    const b = document.createElement("button");
    b.style.setProperty("--c", cor);
    const svg = document.createElementNS(NS, "svg"); svg.setAttribute("viewBox", "0 0 24 24");
    svg.innerHTML = ICONES[id]; // constantes do próprio arquivo, nada vindo de fora
    const rot = document.createElement("span"); rot.className = "rot"; rot.textContent = rotulo;
    b.append(svg, rot);
    b.onclick = () => id === "ficha" ? (fecharTela(), alternarFicha()) : abrirTela(id, cor);
    botoes[id] = b; T("t").append(b);
  }
  function abrirTela(id, cor) {
    if (telaAberta === id) return fecharTela();
    telaAberta = id;
    const [titulo, url] = TELAS[id];
    T("ov").style.setProperty("--c", cor);
    T("ovt").textContent = titulo;
    T("ovf").src = chrome.runtime.getURL(url);
    T("ov").classList.add("on");
    trilhoHost.style.width = "100vw";
    for (const [k, b] of Object.entries(botoes)) b.classList.toggle("on", k === id);
  }
  function fecharTela() {
    telaAberta = null;
    T("ov").classList.remove("on"); T("ovf").src = "about:blank";
    trilhoHost.style.width = TRILHO + "px";
    for (const [k, b] of Object.entries(botoes)) b.classList.toggle("on", k === "ficha" && aberto);
  }
  function marcarFicha() { if (!telaAberta && botoes.ficha) botoes.ficha.classList.toggle("on", aberto); }
  T("ovx").onclick = fecharTela;
  T("ova").onclick = () => { const u = T("ovf").src.replace("embed=1&", ""); window.open(u, "_blank"); fecharTela(); };
  T("ovr").onclick = () => { const f = T("ovf"); f.src = f.src; };
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && telaAberta) fecharTela(); }, true);

  // o Funil pede pra abrir a conversa de um cartão: só aceitamos pedido vindo da própria extensão
  const ORIGEM_EXT = chrome.runtime.getURL("").replace(/\/$/, "");
  window.addEventListener("message", (e) => {
    if (e.origin !== ORIGEM_EXT || !e.data || e.data.alexandria !== "abrirConversa") return;
    const tel = String(e.data.telefone || "").replace(/\D/g, "");
    if (!/^\d{10,15}$/.test(tel)) return;
    fecharTela();
    location.href = "https://web.whatsapp.com/send?phone=" + (tel.length <= 11 ? "55" + tel : tel);
  });
  aplicarLargura();
  carregar(true);
})();
