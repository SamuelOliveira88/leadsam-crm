/* Mi Zap — Minha Sara.
 * O corretor responde as 8 perguntas; a Mi.IA (n8n v3.2) lê pela instância do WhatsApp dele. */
const $ = (id) => document.getElementById(id);
const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(r || { ok: false, erro: "sem resposta" })));
const rpc = async (fn, args) => { const r = await bg({ tipo: "rpc", fn, args }); if (!r.ok) throw new Error(r.erro); return r.dados; };
const aviso = (t, erro) => { const d = document.createElement("div"); d.className = "msg" + (erro ? " erro" : ""); d.textContent = t; $("msg").replaceChildren(t ? d : ""); };

const PERGUNTAS = [
  ["apresentacao", "Como a Mi.IA te apresenta?", "Seu nome, CRECI e a frase.", "Sou a Mi.IA, assistente do Samuel, CRECI 123456"],
  ["regiao", "Onde você atua?", "Cidades e bairros.", "Taboão da Serra, Embu, Campo Limpo"],
  ["tipo_imovel", "Que imóveis você vende?", "Pode ser mais de um.", "MCMV, médio padrão, locação"],
  ["empreendimentos", "Quais empreendimentos ela pode oferecer?", "Preço e condição só os que você confirmou.", "Clube Laguna (Taboão, 2 dorms)…"],
  ["tom", "Como ela deve falar?", "Formal, informal, bem acolhedora? Emoji?", "Acolhedora, informal, emoji só se o cliente usar"],
  ["qualificacao", "O que ela descobre antes de te passar?", "", "Renda, FGTS, entrada, prazo, região"],
  ["passagem", "Quando ela te passa o lead na hora?", "", "Pediu visita, renda acima de R$ 4 mil, pediu pra falar com você"],
  ["limites", "Dias de visita e o que ela NUNCA pode dizer", "", "Seg a sáb, 9h às 18h. Nunca prometer aprovação nem dar desconto"]
];
const AJUSTES = ["nome_assistente", "numero_alerta", "horario_inicio", "horario_fim"];

$("perguntas").replaceChildren(...PERGUNTAS.map(([k, t, p, ex], i) => {
  const c = document.createElement("div"); c.className = "card";
  const h = document.createElement("h3"); const n = document.createElement("span"); n.className = "n"; n.textContent = i + 1; h.append(n, t);
  const d = document.createElement("p"); d.textContent = p;
  const a = document.createElement("textarea"); a.id = k; a.maxLength = 1500; a.placeholder = "Ex.: " + ex; a.oninput = progresso;
  c.append(h, d, a); return c;
}));

function progresso() {
  const n = PERGUNTAS.filter(([k]) => $(k).value.trim()).length;
  $("prog").innerHTML = "";
  const s = document.createElement("span"); s.textContent = `${n} de 8 respondidas`; if (n === 8) s.className = "ok";
  $("prog").append(s, n < 8 ? " · o que faltar, ela faz do jeito padrão" : " · completa");
}

async function carregar() {
  try {
    const d = await rpc("ext_sara_config_ler", {});
    const r = d.respostas || {};
    for (const [k] of PERGUNTAS) $(k).value = r[k] || "";
    for (const k of AJUSTES) $(k).value = r[k] || "";
    $("sub").textContent = d.instancia
      ? `Ligada ao WhatsApp "${d.instancia}". Ela lê isso antes de cada atendimento, então muda na hora.`
      : "Seu WhatsApp ainda não está ligado a uma Mi.IA. Você pode preencher agora; ela começa quando o número for conectado.";
    const lido = d.lido_em ? new Date(d.lido_em) : null;
    if (d.instancia) aviso(lido ? `A Mi.IA leu sua configuração pela última vez em ${lido.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}.`
      : "A Mi.IA ainda não leu esta configuração. Se já chegou mensagem nesse WhatsApp, a v3.2 não está ativa ou faltam as variáveis do Supabase no n8n.", !lido);
    else aviso("");
    progresso();
  } catch (e) { aviso(e.message === "sem_login" ? "Entre na tela Conta primeiro." : /function|404|not find/i.test(e.message) ? "Rode o minha-sara.sql no Supabase." : e.message, true); }
}
$("salvar").onclick = async () => {
  const p = {};
  for (const [k] of PERGUNTAS) p[k] = $(k).value.trim();
  for (const k of AJUSTES) p[k] = $(k).value.trim();
  if (p.numero_alerta && !/^\d{10,13}$/.test(p.numero_alerta.replace(/\D/g, ""))) return aviso("O número dos alertas parece incompleto. Use DDD + número.", true);
  try {
    const r = await rpc("ext_sara_config_salvar", { p_respostas: p });
    aviso(r.completo ? "Salvo. A Mi.IA já atende do seu jeito na próxima mensagem." : "Salvo. O que ficou em branco, ela faz do jeito padrão.");
  } catch (e) { aviso(e.message === "numero_alerta_invalido" ? "O número dos alertas parece incompleto." : e.message, true); }
};
$("recarregar").onclick = carregar;
carregar();
