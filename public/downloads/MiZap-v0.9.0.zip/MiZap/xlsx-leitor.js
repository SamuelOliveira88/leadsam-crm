/*
 * Leitor mínimo de planilhas (xlsx e csv), feito aqui, sem biblioteca de fora.
 * Lê só a primeira aba, só os valores das células. Nada sai do computador neste passo.
 */
const LeitorPlanilha = (() => {
  const u16 = (b, i) => b[i] | (b[i + 1] << 8);
  const u32 = (b, i) => (b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)) >>> 0;

  async function inflar(dados) {
    const ds = new DecompressionStream("deflate-raw");
    const buf = await new Response(new Blob([dados]).stream().pipeThrough(ds)).arrayBuffer();
    return new Uint8Array(buf);
  }

  // Abre o zip (o xlsx é um zip) e devolve { caminho: Uint8Array }
  async function abrirZip(ab, quero) {
    const b = new Uint8Array(ab);
    let fim = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) { if (u32(b, i) === 0x06054b50) { fim = i; break; } }
    if (fim < 0) throw new Error("Arquivo xlsx inválido.");
    const total = u16(b, fim + 10); let p = u32(b, fim + 16);
    const saida = {}; const dec = new TextDecoder();
    for (let k = 0; k < total; k++) {
      if (u32(b, p) !== 0x02014b50) break;
      const metodo = u16(b, p + 10), tam = u32(b, p + 20), nl = u16(b, p + 28), el = u16(b, p + 30), cl = u16(b, p + 32), loc = u32(b, p + 42);
      const nome = dec.decode(b.subarray(p + 46, p + 46 + nl));
      p += 46 + nl + el + cl;
      if (!quero(nome)) continue;
      const ini = loc + 30 + u16(b, loc + 26) + u16(b, loc + 28);
      const bruto = b.subarray(ini, ini + tam);
      saida[nome] = metodo === 0 ? bruto : metodo === 8 ? await inflar(bruto) : null;
    }
    return saida;
  }

  const colNum = (ref) => { let n = 0; for (const c of ref.replace(/\d+/g, "")) n = n * 26 + (c.charCodeAt(0) - 64); return n - 1; };
  const texto = (no) => Array.from(no.getElementsByTagName("t")).map((t) => t.textContent).join("");

  async function lerXlsx(ab) {
    const z = await abrirZip(ab, (n) => n === "xl/sharedStrings.xml" || n === "xl/workbook.xml" || n === "xl/_rels/workbook.xml.rels" || /^xl\/worksheets\/sheet\d+\.xml$/.test(n));
    const dec = new TextDecoder(); const xml = (n) => z[n] ? new DOMParser().parseFromString(dec.decode(z[n]), "application/xml") : null;
    const ss = xml("xl/sharedStrings.xml"); const comp = ss ? Array.from(ss.getElementsByTagName("si")).map(texto) : [];
    // primeira aba de verdade (pela ordem do workbook), com sheet1 como reserva
    let alvo = null;
    const wb = xml("xl/workbook.xml"), rels = xml("xl/_rels/workbook.xml.rels");
    if (wb && rels) {
      const s1 = wb.getElementsByTagName("sheet")[0];
      const rid = s1 && (s1.getAttribute("r:id") || s1.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id"));
      const rel = Array.from(rels.getElementsByTagName("Relationship")).find((r) => r.getAttribute("Id") === rid);
      if (rel) alvo = "xl/" + rel.getAttribute("Target").replace(/^\/?xl\//, "").replace(/^\//, "");
    }
    if (!alvo || !z[alvo]) alvo = Object.keys(z).filter((n) => n.startsWith("xl/worksheets/")).sort()[0];
    if (!alvo) throw new Error("Não achei nenhuma aba na planilha.");
    const sh = xml(alvo); const linhas = [];
    for (const row of Array.from(sh.getElementsByTagName("row"))) {
      const arr = [];
      for (const c of Array.from(row.getElementsByTagName("c"))) {
        const t = c.getAttribute("t"); const v = c.getElementsByTagName("v")[0]; let val = "";
        if (t === "s") val = comp[Number(v && v.textContent)] || "";
        else if (t === "inlineStr") val = texto(c);
        else if (v) { val = v.textContent; if (/^-?\d+(\.\d+)?E\+\d+$/i.test(val)) val = BigInt(Math.round(Number(val))).toString(); }
        arr[colNum(c.getAttribute("r") || "A1")] = val;
      }
      linhas.push(Array.from(arr, (x) => (x == null ? "" : String(x).trim())));
    }
    return linhas;
  }

  // CSV ou texto colado do Excel (tab). Detecta ; , ou tab. Respeita aspas.
  function lerTexto(t) {
    t = t.replace(/^\uFEFF/, "");
    const prim = t.split(/\r?\n/)[0] || "";
    const sep = prim.includes("\t") ? "\t" : (prim.split(";").length >= prim.split(",").length ? ";" : ",");
    const linhas = []; let lin = [], cel = "", aspas = false;
    for (let i = 0; i < t.length; i++) {
      const c = t[i];
      if (aspas) { if (c === '"') { if (t[i + 1] === '"') { cel += '"'; i++; } else aspas = false; } else cel += c; continue; }
      if (c === '"') aspas = true;
      else if (c === sep) { lin.push(cel.trim()); cel = ""; }
      else if (c === "\n") { lin.push(cel.trim()); linhas.push(lin); lin = []; cel = ""; }
      else if (c !== "\r") cel += c;
    }
    if (cel !== "" || lin.length) { lin.push(cel.trim()); linhas.push(lin); }
    return linhas.filter((l) => l.some((x) => x !== ""));
  }

  // Descobre as colunas: pelo cabeçalho, ou pelo conteúdo.
  const ehTel = (x) => { const d = String(x || "").replace(/\D/g, ""); return d.length >= 10 && d.length <= 13; };
  function mapear(linhas) {
    if (!linhas.length) return { contatos: [], colunas: {} };
    const cab = linhas[0].map((x) => String(x).toLowerCase());
    const acha = (re) => cab.findIndex((x) => re.test(x));
    let iTel = acha(/telefone|celular|whats|fone|n[uú]mero/), iNome = acha(/nome|cliente/), iEmp = acha(/empreend|im[oó]vel|projeto|campanha/);
    let dados = linhas;
    if (iTel >= 0 && !ehTel(linhas[0][iTel])) dados = linhas.slice(1);
    else {
      // sem cabeçalho reconhecível: a coluna com mais telefones vira telefone; a 1ª com letras vira nome
      const nCol = Math.max(...linhas.map((l) => l.length));
      let melhor = -1, conta = 0;
      for (let c = 0; c < nCol; c++) { const n = linhas.filter((l) => ehTel(l[c])).length; if (n > conta) { conta = n; melhor = c; } }
      iTel = melhor;
      if (iTel >= 0 && !ehTel(linhas[0][iTel])) dados = linhas.slice(1);
      if (iNome < 0) for (let c = 0; c < nCol; c++) { if (c !== iTel && dados.some((l) => /[a-zà-ú]{2}/i.test(l[c] || ""))) { iNome = c; break; } }
    }
    if (iTel < 0) throw new Error("Não achei a coluna de telefone.");
    const contatos = dados.map((l) => ({
      nome: iNome >= 0 ? (l[iNome] || "") : "",
      telefone: String(l[iTel] || ""),
      empreendimento: iEmp >= 0 ? (l[iEmp] || "") : ""
    })).filter((c) => c.telefone.replace(/\D/g, "").length >= 8);
    return { contatos, colunas: { telefone: iTel, nome: iNome, empreendimento: iEmp } };
  }

  async function lerArquivo(arq) {
    if (/\.xlsx$/i.test(arq.name)) return mapear(await lerXlsx(await arq.arrayBuffer()));
    if (/\.xls$/i.test(arq.name)) throw new Error("Arquivo .xls antigo: salve como .xlsx ou .csv no Excel.");
    return mapear(lerTexto(await arq.text()));
  }
  return { lerArquivo, lerColado: (t) => mapear(lerTexto(t)) };
})();
