/* Mi Zap — popup. */
const $ = (id) => document.getElementById(id);
const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(r || { ok: false, erro: "sem resposta" })));
const rpc = async (fn, args) => { const r = await bg({ tipo: "rpc", fn, args }); if (!r.ok) throw new Error(r.erro); return r.dados; };
const aviso = (alvo, t, erro) => { const d = document.createElement("div"); d.className = "msg" + (erro ? " erro" : ""); d.textContent = t; $(alvo).replaceChildren(d); };

document.querySelectorAll("nav button").forEach((b) => b.onclick = () => {
  document.querySelectorAll("nav button, section").forEach((x) => x.classList.remove("on"));
  b.classList.add("on"); $(b.dataset.t).classList.add("on");
  if (b.dataset.t === "respostas") carregarRespostas();
  if (b.dataset.t === "equipe") carregarEquipe();
  if (b.dataset.t === "whatsapp") carregarWhatsapp(); else pararQr();
});

async function status() {
  const s = await bg({ tipo: "status" });
  $("logado").hidden = !s.logado; $("login").hidden = !!s.logado; $("criar").hidden = true;
  if (s.logado) { $("quem").textContent = "Conectado como " + s.email; await aceitarPendente(); }
  await ajustarAbas(!!s.logado);
}

// a aba Equipe só aparece para o admin (o banco também barra; isto é só o visual)
async function ajustarAbas(logado) {
  let admin = false;
  if (logado) { try { await rpc("ext_equipe_listar", {}); admin = true; } catch (e) {} }
  const b = document.querySelector('nav button[data-t="equipe"]');
  b.hidden = !admin;
  if (!admin && $("equipe").classList.contains("on")) document.querySelector('nav button[data-t="conta"]').click();
}

// convite guardado até o primeiro login (quando o Supabase pede confirmação por e-mail)
async function aceitarPendente() {
  const { convitePendente: c } = await chrome.storage.local.get("convitePendente");
  if (!c) return;
  try {
    const r = c.codigo ? await rpc("ext_aceitar_convite", { p_codigo: c.codigo, p_nome: c.nome })
                       : await rpc("ext_cadastro_livre", { p_nome: c.nome });
    await chrome.storage.local.remove("convitePendente");
    aviso("cmsg", "Cadastro concluído, " + r.nome + ". Volte ao WhatsApp Web.");
  } catch (e) {
    if (/já está cadastrado|inválido|acabaram/.test(e.message)) await chrome.storage.local.remove("convitePendente");
    aviso("cmsg", e.message, true);
  }
}
$("irCriar").onclick = (e) => { e.preventDefault(); $("login").hidden = true; $("criar").hidden = false; $("cmsg").replaceChildren(); };
$("voltarLogin").onclick = () => { $("criar").hidden = true; $("login").hidden = false; };
$("criar").onsubmit = async (e) => {
  e.preventDefault();
  const codigo = $("ccod").value.trim().toUpperCase(), nome = $("cnome").value.trim();
  if (codigo && !/^[A-Z0-9]{8}$/.test(codigo)) return aviso("cmsg", "O código tem 8 letras e números.", true);
  await chrome.storage.local.set({ convitePendente: { codigo, nome } });
  const r = await bg({ tipo: "criar_conta", email: $("cem").value.trim(), senha: $("cpw").value, nome });
  $("cpw").value = "";
  if (!r.ok) { await chrome.storage.local.remove("convitePendente"); return aviso("cmsg", "Não criou: " + r.erro, true); }
  if (r.logado) return status();
  $("criar").hidden = true; $("login").hidden = false;
  aviso("cmsg", "Conta criada. Abra o e-mail de confirmação, clique no link e depois entre aqui com o mesmo e-mail e senha.");
};
$("login").onsubmit = async (e) => {
  e.preventDefault();
  const r = await bg({ tipo: "login", email: $("em").value.trim(), senha: $("pw").value });
  $("pw").value = "";
  if (!r.ok) return aviso("cmsg", "Não entrou: " + r.erro, true);
  aviso("cmsg", "Pronto. Volte ao WhatsApp Web.");
  status();
};

// ---- Meu plano ----
const reais = (c) => "R$ " + (c / 100).toFixed(2).replace(".", ",");
const CICLO = { anual: "por ano", mensal: "por mês" };
const MOD = { ferramentas: ["Ferramentas", "Funil, planilha, disparo, lembretes e equipe."], ia: ["Mi.IA", "A vendedora com IA atendendo no seu WhatsApp."] };
async function carregarPlano() {
  try {
    const p = await rpc("ext_plano_meu", {});
    const st = $("pstatus");
    st.textContent = p.em_teste ? `Teste grátis: tudo liberado por mais ${p.teste_dias} dia(s).` : (p.ferramentas || p.ia) ? "Seu plano está ativo." : "Plano grátis: ficha, notas e respostas rápidas.";
    const linhas = Object.keys(MOD).map((k) => {
      const d = document.createElement("div"); d.className = "item";
      const t = document.createElement("b"); t.textContent = (p[k] ? "✅ " : "🔒 ") + MOD[k][0];
      const s = document.createElement("small"); s.textContent = " " + MOD[k][1];
      const ate = p[k + "_ate"]; const v = (p.precos || []).filter((x) => x.modulo === k).map((x) => reais(x.centavos) + " " + (CICLO[x.ciclo] || x.ciclo)).join(" · ");
      const e = document.createElement("small"); e.textContent = (ate && new Date(ate) > new Date() ? (new Date(ate).getFullYear() >= 2100 ? "sem vencimento" : "vale até " + new Date(ate).toLocaleDateString("pt-BR")) : p.em_teste ? "no teste" : (v ? v : ""));
      d.append(t, s, document.createElement("br"), e); return d;
    });
    $("pmods").replaceChildren(...linhas);
  } catch (e) { $("pstatus").textContent = e.message === "sem_login" ? "Entre na aba Conta primeiro." : e.message; $("pmods").replaceChildren(); }
}
document.querySelector('nav button[data-t="plano"]').addEventListener("click", carregarPlano);
// dono da plataforma: ver e definir plano das empresas (aparece na aba Equipe)
async function carregarPlanosEmpresas() {
  try {
    const l = await rpc("ext_planos_listar", {});
    $("eplanos").hidden = false;
    $("pemp").replaceChildren(...l.map((x) => new Option(x.empresa, x.empresa)));
    $("eplanolista").replaceChildren(...l.map((x) => { const d = document.createElement("div"); d.className = "item";
      const b = document.createElement("b"); b.textContent = x.empresa;
      const s = document.createElement("small"); s.textContent = " Ferramentas: " + (x.ferramentas ? "sim" : "não") + " · Mi.IA: " + (x.ia ? "sim" : "não") + (x.teste_ate && new Date(x.teste_ate) > new Date() ? " · teste até " + new Date(x.teste_ate).toLocaleDateString("pt-BR") : "");
      d.append(b, s); return d; }));
  } catch (e) { $("eplanos").hidden = true; }
}
$("paplicar").onclick = async () => {
  try { await rpc("ext_plano_definir", { p_empresa: $("pemp").value, p_modulo: $("pmod").value, p_dias: Number($("pdias").value) || null }); aviso("pmsg", "Feito."); carregarPlanosEmpresas(); }
  catch (e) { aviso("pmsg", e.message, true); }
};
$("abrirPlanilha").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("planilha.html") });
$("sair").onclick = async () => { await bg({ tipo: "logout" }); aviso("cmsg", "Você saiu."); status(); };

function limparForm() { $("rid").value = ""; $("rtit").value = ""; $("rtxt").value = ""; $("remp").value = ""; }
$("rnovo").onclick = limparForm;
$("rsalvar").onclick = async () => {
  try {
    await rpc("ext_resposta_salvar", { p_id: $("rid").value ? Number($("rid").value) : null, p_empreendimento: $("remp").value, p_titulo: $("rtit").value, p_texto: $("rtxt").value });
    aviso("rmsg", "Salva."); limparForm(); carregarRespostas();
  } catch (e) { aviso("rmsg", e.message, true); }
};
async function carregarRespostas() {
  try {
    const [emps, lista] = await Promise.all([rpc("ext_empreendimentos", {}), rpc("ext_respostas_listar", {})]);
    $("rempLista").replaceChildren(...(emps || []).map((e) => { const o = document.createElement("option"); o.value = e; return o; }));
    $("rlista").replaceChildren(...(lista || []).map((r) => {
      const d = document.createElement("div"); d.className = "item";
      const t = document.createElement("b"); t.textContent = r.titulo;
      const s = document.createElement("small"); s.textContent = " " + (r.empreendimento || "geral");
      const ed = document.createElement("button"); ed.className = "b s"; ed.textContent = "editar";
      ed.onclick = () => { $("rid").value = r.id; $("rtit").value = r.titulo; $("rtxt").value = r.texto; $("remp").value = r.empreendimento || ""; };
      const ap = document.createElement("button"); ap.className = "b s"; ap.textContent = "apagar";
      ap.onclick = async () => { if (confirm("Apagar " + r.titulo + "?")) { await rpc("ext_resposta_apagar", { p_id: r.id }); carregarRespostas(); } };
      d.append(t, s, document.createElement("br"), ed, " ", ap); return d;
    }));
  } catch (e) { aviso("rmsg", e.message === "sem_login" ? "Entre na aba Conta primeiro." : e.message, true); }
}
$("abrirPlanilha").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("planilha.html") });
status();

// ---- Equipe (só admin) ----
const dataBR = (t) => t ? (new Date(t).getFullYear() >= 2100 ? "nunca expira" : new Date(t).toLocaleDateString("pt-BR")) : "";
$("egerar").onclick = async () => {
  try {
    const r = await rpc("ext_convite_criar", { p_dias: Number($("edias").value), p_modo: $("emodo").value, p_empresa: $("eempresa").value.trim() || null });
    aviso("emsg", "Convite: " + r.codigo + (new Date(r.expira_em).getFullYear() >= 2100 ? " (não expira, vale 1 uso)" : " (vale até " + dataBR(r.expira_em) + ")") + ". Mande pro corretor junto com a extensão.");
    carregarEquipe(true);
  } catch (e) { aviso("emsg", e.message, true); }
};
async function carregarEquipe(manterAviso) {
  try {
    const d = await rpc("ext_equipe_listar", {});
    if (!manterAviso) $("emsg").replaceChildren();
    const linha = (txt, sub, botao) => { const x = document.createElement("div"); x.className = "item";
      const b = document.createElement("b"); b.textContent = txt; const s = document.createElement("small"); s.textContent = " " + sub;
      x.append(b, s); if (botao) x.append(document.createElement("br"), botao); return x; };
    const btn = (t, fn) => { const b = document.createElement("button"); b.className = "b s"; b.textContent = t; b.onclick = fn; return b; };
    const MODO = { proprio: "próprio WhatsApp", numero_mae: "número da imobiliária" };
    const t1 = document.createElement("p"); t1.innerHTML = "<b>Corretores</b>";
    const cor = (d.corretores || []).map((k) => linha(k.nome + (k.admin ? " (admin)" : ""),
      (k.empresa ? k.empresa + " · " : "") + (k.ativo ? "" : "desligado · ") + MODO[k.modo] + (k.modo === "proprio" && !k.tem_numero ? " · sem número ligado" : ""),
      k.admin ? null : btn(k.ativo ? "desligar" : "religar", async () => {
        if (!k.ativo || confirm("Desligar " + k.nome + "? Ele perde o acesso, nada é apagado.")) { await rpc("ext_corretor_ativo", { p_corretor_id: k.corretor_id, p_ativo: !k.ativo }); carregarEquipe(); }
      })));
    const t2 = document.createElement("p"); t2.innerHTML = "<b>Convites</b>";
    const conv = (d.convites || []).map((c) => {
      const venc = new Date(c.expira_em) < new Date();
      const st = c.usado ? "usado em " + dataBR(c.usado_em) : c.cancelado ? "cancelado" : venc ? "vencido" : (new Date(c.expira_em).getFullYear() >= 2100 ? "não expira" : "vale até " + dataBR(c.expira_em));
      return linha(c.codigo, (c.empresa ? c.empresa + " · " : "") + MODO[c.modo] + " · " + st,
        (!c.usado && !c.cancelado && !venc) ? btn("cancelar", async () => { await rpc("ext_convite_cancelar", { p_codigo: c.codigo }); carregarEquipe(); }) : null);
    });
    $("elista").replaceChildren(t1, ...cor, t2, ...(conv.length ? conv : [linha("Nenhum convite ainda", "")]));
    carregarPlanosEmpresas();
  } catch (e) { aviso("emsg", e.message === "sem_login" ? "Entre na aba Conta primeiro." : e.message, true); $("elista").replaceChildren(); }
}

// aberto por dentro do WhatsApp (menu da esquerda): ocupa a tela toda e já vai pra aba pedida
(() => {
  const q = new URLSearchParams(location.search);
  if (!q.has("embed")) return;
  document.body.classList.add("embed");
  const b = document.querySelector(`nav button[data-t="${q.get("t") || "conta"}"]`);
  if (b) b.click();
})();


// ---- WhatsApp: conectar por QR ----
let qTimer = null;
function pararQr() { if (qTimer) { clearInterval(qTimer); qTimer = null; } }
const qErros = { modo_numero_mae: "Você atende pelo número da imobiliária, não precisa conectar.", muitos_pedidos: "Muitos pedidos seguidos. Espere uns minutos e tente de novo.", sem_acesso: "Seu acesso não está ativo." };
function pintarQr(s) {
  const img = $("qimg"), aj = $("qajuda");
  img.hidden = aj.hidden = true; $("qcancelar").hidden = true; $("qconectar").hidden = false;
  const st = s.status;
  if (st === "conectado") { pararQr(); $("qconectar").hidden = true; return aviso("qmsg", "WhatsApp conectado. Agora preencha a Minha Mi.IA (menu da esquerda, no WhatsApp Web). A Mi.IA só começa a responder no seu número depois disso."); }
  if (st === "numero_mae") { pararQr(); $("qconectar").hidden = true; return aviso("qmsg", qErros.modo_numero_mae); }
  if (st === "pedido" || st === "criando") { $("qconectar").hidden = true; $("qcancelar").hidden = false; return aviso("qmsg", "Preparando a conexão... pode levar até 1 minuto."); }
  if (st === "qr") {
    $("qconectar").hidden = true; $("qcancelar").hidden = false;
    if (s.qr && /^[A-Za-z0-9+/=]+$/.test(s.qr) && s.qr.length < 200000) {
      img.src = "data:image/png;base64," + s.qr; img.hidden = aj.hidden = false; return aviso("qmsg", "Escaneie o QR com o seu celular.");
    }
    return aviso("qmsg", "Gerando o QR...");
  }
  pararQr();
  if (st === "erro") return aviso("qmsg", "Não conectou: " + (s.erro || "erro") + ". Clique em Conectar para tentar de novo.", true);
  if (st === "expirado") return aviso("qmsg", "O QR venceu. Clique em Conectar para gerar outro.", true);
  $("qmsg").replaceChildren();
}
async function tickQr() { try { const s = await rpc("ext_qr_status", {}); pintarQr(s); return s.status; } catch (e) { pararQr(); aviso("qmsg", e.message === "sem_login" ? "Entre na aba Conta primeiro." : (qErros[e.message] || e.message), true); return "erro"; } }
function carregarWhatsapp() { pararQr(); tickQr().then((st) => { if (["pedido", "criando", "qr"].includes(st)) qTimer = qTimer || setInterval(tickQr, 3000); }); }
$("qconectar").onclick = async () => {
  try { await rpc("ext_qr_pedir", {}); pararQr(); await tickQr(); qTimer = setInterval(tickQr, 3000); }
  catch (e) { aviso("qmsg", qErros[e.message] || e.message, true); }
};
$("qcancelar").onclick = async () => { try { await rpc("ext_qr_cancelar", {}); } catch (e) {} pararQr(); aviso("qmsg", "Cancelado."); $("qimg").hidden = $("qajuda").hidden = true; $("qcancelar").hidden = true; $("qconectar").hidden = false; };
