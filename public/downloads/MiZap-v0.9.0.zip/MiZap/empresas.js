/* Mi Zap — Minhas empresas. Cadastro das incorporadoras do corretor + documentos de cada uma.
 * Tudo passa pelas funções ext_* (filtradas por empresa). Arquivos sobem pro bucket ext-docs/<empresa>/... pelo background. */
const $ = (id) => document.getElementById(id);
const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(r || { ok: false, erro: "sem resposta" })));
const rpc = async (fn, args) => { const r = await bg({ tipo: "rpc", fn, args }); if (!r.ok) throw new Error(r.erro); return r.dados; };
const aviso = (t, erro) => { const d = document.createElement("div"); d.className = "msg" + (erro ? " erro" : ""); d.textContent = t; $("msg").replaceChildren(t ? d : ""); };
const MB15 = 15 * 1024 * 1024;
const TIPOS = ["Tabela de preços", "Book / apresentação", "Memorial descritivo", "Tabela de comissão", "Planta", "Fotos", "Contrato / regras", "Outro"];
let dados = [];

function el(tag, attrs, ...filhos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) { if (k === "on") for (const [ev, fn] of Object.entries(v)) e.addEventListener(ev, fn); else if (k === "textContent") e.textContent = v; else e.setAttribute(k, v); }
  for (const f of filhos) if (f != null) e.append(f);
  return e;
}
const erroAmigavel = (e) => ({
  sem_login: "Entre na tela Conta primeiro.",
  nome_invalido: "Escreva o nome (pelo menos 2 letras).",
  limite_empresas: "Limite de 100 empresas.",
  limite_documentos: "Limite de 500 documentos.",
  link_precisa_https: "O link precisa começar com https://",
  empresa_nao_encontrada: "Essa empresa não existe mais. Recarregue."
}[e.message] || e.message);

async function carregar() {
  try { dados = await rpc("ext_parceiras_listar", {}); desenhar(); }
  catch (e) { aviso(erroAmigavel(e), true); }
}

function desenhar() {
  if (!dados.length) { $("lista").replaceChildren(el("div", { class: "vazio" }, "Nenhuma empresa ainda. Escreva o nome acima e clique em Adicionar.")); return; }
  $("lista").replaceChildren(...dados.map(cartao));
}

function cartao(p) {
  const docs = p.docs || [];
  const corpo = el("div", { class: "card" });
  const apagarEmp = el("button", { class: "p", textContent: "Apagar empresa", on: { click: async () => {
    if (!confirm(`Apagar "${p.nome}" e os ${docs.length} documento(s) dela?`)) return;
    try { const r = await rpc("ext_parceira_apagar", { p_id: p.id }); await bg({ tipo: "doc_remover", paths: r.paths || [] }); aviso("Empresa apagada."); carregar(); } catch (e) { aviso(erroAmigavel(e), true); }
  } } });
  corpo.append(el("div", { class: "cab" }, el("h3", { textContent: p.nome }), el("small", { textContent: docs.length + " doc" }), apagarEmp));
  if (p.obs) corpo.append(el("div", { class: "obs", textContent: p.obs }));

  for (const d of docs) {
    corpo.append(el("div", { class: "doc" },
      el("div", { class: "n" }, el("b", { textContent: d.nome }), el("small", { textContent: [d.tipo, d.empreendimento, d.arquivo ? "arquivo" : "link"].filter(Boolean).join(" · ") })),
      el("a", { href: d.link, target: "_blank", rel: "noopener", textContent: "Abrir" }),
      el("button", { class: "p", textContent: "Apagar", on: { click: async () => {
        if (!confirm(`Apagar "${d.nome}"?`)) return;
        try { const r = await rpc("ext_doc_apagar", { p_id: d.id }); await bg({ tipo: "doc_remover", paths: r.paths || [] }); carregar(); } catch (e) { aviso(erroAmigavel(e), true); }
      } } })));
  }

  // adicionar documento
  const nome = el("input", { maxlength: "120", placeholder: "Nome do documento. Ex.: Tabela outubro" });
  const tipo = el("select", {}, ...TIPOS.map((t) => el("option", { textContent: t })));
  const emp = el("input", { maxlength: "80", placeholder: "Empreendimento (opcional). Ex.: Clube Laguna" });
  const link = el("input", { placeholder: "https://... (se for um link)" });
  const arq = el("input", { type: "file", accept: ".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt" });
  const salvar = el("button", { textContent: "Salvar documento" });
  salvar.onclick = async () => {
    const f = arq.files[0]; const url = link.value.trim();
    if (!f && !url) return aviso("Escolha um arquivo ou cole um link.", true);
    if (f && f.size > MB15) return aviso("Arquivo acima de 15 MB. Use um link (Drive, Dropbox).", true);
    if (!f && !/^https:\/\//i.test(url)) return aviso("O link precisa começar com https://", true);
    salvar.disabled = true; salvar.textContent = "Enviando...";
    try {
      let lk = url, path = "";
      if (f) {
        const dataUrl = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(new Error("Não consegui ler o arquivo.")); r.readAsDataURL(f); });
        const r = await bg({ tipo: "doc_subir", dataUrl, nome: f.name, mime: f.type });
        if (!r.ok) throw new Error(r.erro);
        lk = r.url; path = r.path;
      }
      const nm = nome.value.trim() || (f ? f.name.replace(/\.[^.]+$/, "") : "Documento");
      try { await rpc("ext_doc_salvar", { p_id: null, p_parceira_id: p.id, p_nome: nm, p_tipo: tipo.value, p_empreendimento: emp.value, p_link: lk, p_path: path }); }
      catch (e) { if (path) await bg({ tipo: "doc_remover", paths: [path] }); throw e; }
      aviso("Documento salvo."); carregar();
    } catch (e) { aviso(erroAmigavel(e), true); salvar.disabled = false; salvar.textContent = "Salvar documento"; }
  };
  corpo.append(el("div", { class: "novo" },
    el("b", { textContent: "Adicionar documento" }),
    el("div", { class: "duas" }, el("div", {}, el("label", { textContent: "Nome" }), nome), el("div", {}, el("label", { textContent: "Tipo" }), tipo)),
    el("label", { textContent: "Empreendimento (para aparecer na ficha do contato desse empreendimento)" }), emp,
    el("div", { class: "duas" }, el("div", {}, el("label", { textContent: "Arquivo do computador (até 15 MB)" }), arq), el("div", {}, el("label", { textContent: "ou link" }), link)),
    el("div", { style: "margin-top:8px" }, salvar)));
  return corpo;
}

$("criar").onclick = async () => {
  const n = $("nova").value.trim();
  if (n.length < 2) return aviso("Escreva o nome da empresa.", true);
  try { await rpc("ext_parceira_salvar", { p_id: null, p_nome: n, p_obs: "" }); $("nova").value = ""; aviso("Empresa adicionada. Agora anexe os documentos dela."); carregar(); }
  catch (e) { aviso(erroAmigavel(e), true); }
};
$("nova").addEventListener("keydown", (e) => { if (e.key === "Enter") $("criar").click(); });
carregar();
